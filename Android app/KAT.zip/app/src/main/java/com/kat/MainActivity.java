package com.kat;

import android.animation.*;
import android.animation.ObjectAnimator;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Transaction;
import com.google.firebase.database.MutableData;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DatabaseError;

public class MainActivity extends AppCompatActivity {
	
	private ArrayList<HashMap<String, Object>> _BackupListmap = new ArrayList<>();
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private boolean active = false;
	private HashMap<String, Object> data = new HashMap<>();
	private HashMap<String, Object> child = new HashMap<>();
	private boolean responded = false;
	private double state = 0;
	
	private ArrayList<String> tips = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> click = new ArrayList<>();
	
	private LinearLayout ln_1;
	private ImageView im_1;
	private TextView counter;
	
	private TimerTask time;
	private ObjectAnimator fade = new ObjectAnimator();
	private ObjectAnimator size = new ObjectAnimator();
	private ObjectAnimator size2 = new ObjectAnimator();
	private TimerTask delay;
	private SharedPreferences status;
	private DatabaseReference Buzzer = _firebase.getReference("/");
	private ChildEventListener _Buzzer_child_listener;
	private SharedPreferences clicks;
	private DatabaseReference clickCounter = _firebase.getReference("/");
	private ChildEventListener _clickCounter_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		ln_1 = findViewById(R.id.ln_1);
		im_1 = findViewById(R.id.im_1);
		counter = findViewById(R.id.counter);
		status = getSharedPreferences("status", Activity.MODE_PRIVATE);
		clicks = getSharedPreferences("clicks", Activity.MODE_PRIVATE);
		
		im_1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (active) {
					state = 2;
					responded = false;
					try{
						clicks.edit().putString("clicks", String.valueOf((long)(Double.parseDouble(clicks.getString("clicks", "")) + 1))).commit();
						counter.setText(clicks.getString("clicks", ""));
					}catch(Exception e){
						 
					}
					Buzzer.child("Buzzer").removeValue();
					DatabaseReference led = FirebaseDatabase.getInstance().getReference("Buzzer");
					FirebaseDatabase database = FirebaseDatabase.getInstance("https://kizohi-annoyinger-tool-default-rtdb.firebaseio.com");
					
					HashMap<String, Object> data = new HashMap<>();
					data.put("state", 1);
					
					led.setValue(data)
					    .addOnSuccessListener(aVoid -> {
						        
						time = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										FirebaseDatabase database = FirebaseDatabase.getInstance();
										        DatabaseReference ref = database.getReference("Buzzer/state");
										
										        ref.addListenerForSingleValueEvent(new ValueEventListener() {
											            @Override
											            public void onDataChange(DataSnapshot snapshot) {
												                if (snapshot.exists()) {
													                    long state = snapshot.getValue(Long.class);
													                    
													if (state == 0) {
														active = true;
														status.edit().putString("button", "1").commit();
														fade.setTarget(im_1);
														fade.setPropertyName("alpha");
														fade.setFloatValues((float)(0.5d), (float)(1));
														fade.setDuration((int)(100));
														fade.start();
														size.setTarget(im_1);
														size.setPropertyName("scaleX");
														size.setFloatValues((float)(0.95d), (float)(1));
														size.setDuration((int)(100));
														size.start();
														size2.setTarget(im_1);
														size2.setPropertyName("scaleY");
														size2.setFloatValues((float)(0.95d), (float)(1));
														size2.setDuration((int)(100));
														size2.start();
														time.cancel();
														delay.cancel();
													}
													             } else {
													                    
													                }
												            }
											
											            @Override
											            public void onCancelled(DatabaseError error) {
												                
												            }
											        });
									}
								});
							}
						};
						_timer.scheduleAtFixedRate(time, (int)(2500), (int)(150));
						    })
					    .addOnFailureListener(e -> {
						    
						SketchwareUtil.showMessage(getApplicationContext(), "Error");
					});
					
					data.clear();
					delay = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									if (state == 1) {
										SketchwareUtil.showMessage(getApplicationContext(), "esp not responding");
									}
								}
							});
						}
					};
					_timer.schedule(delay, (int)(7000));
					active = false;
					fade.setTarget(im_1);
					fade.setPropertyName("alpha");
					fade.setFloatValues((float)(1), (float)(0.5d));
					fade.setDuration((int)(100));
					fade.start();
					size.setTarget(im_1);
					size.setPropertyName("scaleX");
					size.setFloatValues((float)(1), (float)(0.95d));
					size.setDuration((int)(100));
					size.start();
					size2.setTarget(im_1);
					size2.setPropertyName("scaleY");
					size2.setFloatValues((float)(1), (float)(0.95d));
					size2.setDuration((int)(100));
					size2.start();
				}
			}
		});
		
		_Buzzer_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		Buzzer.addChildEventListener(_Buzzer_child_listener);
		
		_clickCounter_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		clickCounter.addChildEventListener(_clickCounter_child_listener);
	}
	
	private void initializeLogic() {
		active = true;
		if (!clicks.contains("clicks")) {
			clicks.edit().putString("clicks", "0").commit();
		}
		counter.setTextSize((int)35);
		counter.setText(clicks.getString("clicks", ""));
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}